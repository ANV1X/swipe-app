import { Product, formatPrice } from '../api/client'

interface Props { product: Product }

const MP_COLORS: Record<string, string> = {
  wb:     '#CB11AB',
  ozon:   '#005BFF',
  lamoda: '#1A1A1A',
}

export default function SwipeCard({ product }: Props) {
  const discount = product.price_old
    ? Math.round((1 - product.price / product.price_old) * 100)
    : null
  const mpColor = MP_COLORS[product.marketplace] ?? '#333'

  return (
    <div className="swipe-card" style={{
      position: 'relative',
      width: '100%',
      height: '100%',
      borderRadius: '24px',
      overflow: 'hidden',
      backgroundColor: 'var(--surface)',
      boxShadow: '0 10px 30px rgba(0,0,0,0.06)',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Обертка изображения на всю доступную высоту карточки */}
      <div className="card-image-wrap" style={{ 
        position: 'relative', 
        flex: 1, 
        width: '100%', 
        height: '100%', 
        backgroundColor: '#F5F5F7' 
      }}>
        <img 
          src={product.image_url} 
          alt={product.title} 
          draggable={false} 
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            display: 'block'
          }}
        />

        {/* Размытый градиент внизу для идеальной читаемости белого текста */}
        <div style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          height: '40%',
          background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.4) 50%, rgba(0,0,0,0) 100%)',
          pointerEvents: 'none',
          zIndex: 2
        }} />

        {/* Верхние аккуратные бейджи */}
        <div style={{ 
          position: 'absolute', 
          top: '14px', 
          left: '14px', 
          right: '14px', 
          display: 'flex', 
          justifyContent: 'space-between',
          alignItems: 'center',
          zIndex: 3
        }}>
          {/* Маркетплейс */}
          <div className="card-marketplace-badge" style={{ 
            backgroundColor: 'rgba(255, 255, 255, 0.92)',
            backdropFilter: 'blur(4px)',
            color: mpColor,
            padding: '5px 12px',
            borderRadius: '20px',
            fontSize: '12px',
            fontWeight: 700,
            boxShadow: '0 2px 8px rgba(0,0,0,0.05)'
          }}>
            {{ wb: 'Wildberries', ozon: 'Ozon', lamoda: 'Lamoda' }[product.marketplace] ?? product.marketplace}
          </div>

          {/* Процент скидки */}
          {discount && (
            <div className="discount-badge" style={{
              backgroundColor: '#FF3B30',
              color: '#FFF',
              padding: '5px 10px',
              borderRadius: '20px',
              fontSize: '12px',
              fontWeight: 700,
              letterSpacing: '-0.5px'
            }}>
              −{discount}%
            </div>
          )}
        </div>

        {/* Информация о товаре — прямо поверх картинки внизу, как в Tinder/Figma */}
        <div className="card-info" style={{
          position: 'absolute',
          bottom: 0,
          left: 0,
          right: 0,
          padding: '20px',
          color: '#FFFFFF',
          zIndex: 3,
          display: 'flex',
          flexDirection: 'column',
          gap: '4px'
        }}>
          {product.brand && (
            <p className="card-brand" style={{ 
              fontSize: '13px', 
              fontWeight: 700, 
              textTransform: 'uppercase', 
              letterSpacing: '1px',
              color: 'rgba(255, 255, 255, 0.7)',
              margin: 0
            }}>
              {product.brand}
            </p>
          )}
          
          <p className="card-title" style={{ 
            fontSize: '19px', 
            fontWeight: 600, 
            lineHeight: '1.3',
            margin: '0 0 6px 0',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
          }}>
            {product.title}
          </p>

          <div className="card-price-row" style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
            <span className="card-price" style={{ fontSize: '22px', fontWeight: 800 }}>
              {formatPrice(product.price)}
            </span>
            {product.price_old && (
              <span className="card-price-old" style={{ 
                fontSize: '15px', 
                textDecoration: 'line-through', 
                color: 'rgba(255, 255, 255, 0.5)',
                fontWeight: 500
              }}>
                {formatPrice(product.price_old)}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}